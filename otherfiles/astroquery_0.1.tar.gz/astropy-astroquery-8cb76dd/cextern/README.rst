External Packages/Libraries
===========================

This directory contains C extensions included with the package. Note that only
C extensions should be included in this directory - pure Cython code should be
placed in the package source tree, and wrapper Cython code for C libraries
included here should be in the packagename/wrappers directory.

