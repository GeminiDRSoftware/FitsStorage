
# $Id: cgitest.py 106619 2004-11-25 22:10:52Z nd $

print "Content-type: text/plain\n"
print "test ok"

